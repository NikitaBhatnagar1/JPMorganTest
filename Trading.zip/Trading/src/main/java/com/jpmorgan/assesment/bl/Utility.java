package com.jpmorgan.assesment.bl;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.jpmorgan.assesment.common.CommonConstant;
import com.jpmorgan.assesment.dto.InstructionDTO;

/**
 * Utility class to have all the core logic require to process instruction.
 * @author 
 *
 */
public class Utility {
	
	private static final Logger LOGGER = Logger.getLogger( Utility.class.getName() );

	/**
	 * Method to read instruction data from xml.
	 * 
	 * @return InstList List.
	 */
	public static List<InstructionDTO> getInstructionData(String fileName) {
		List<InstructionDTO> InstList = new ArrayList<InstructionDTO>();
		
		try {
				File fXmlFile = new File(fileName);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory
						.newInstance();
				DocumentBuilder dBuilder;
				dBuilder = dbFactory.newDocumentBuilder();
				Document doc;
				doc = dBuilder.parse(fXmlFile);
				doc.getDocumentElement().normalize();
				NodeList nList = doc.getElementsByTagName(CommonConstant.INSTRUCTION);
				
				for (int i = 0; i < nList.getLength(); i++) {
					InstructionDTO insDto = new InstructionDTO();
					Node nNode = nList.item(i);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						insDto.setEntity(eElement.getElementsByTagName(CommonConstant.ENTITY).item(0).getTextContent());
						insDto.setAgreedFx(Double.parseDouble(eElement.getElementsByTagName(CommonConstant.AGREED_FX).item(0).getTextContent()));
						insDto.setCurrency(eElement.getElementsByTagName(CommonConstant.CURENCY).item(0).getTextContent());
						insDto.setPricePerUnit(Double.parseDouble(eElement.getElementsByTagName(CommonConstant.PRICE_PER_UNIT).item(0).getTextContent()));
						insDto.setSettlementDate(eElement.getElementsByTagName(CommonConstant.SETTLEMENT_DATE).item(0).getTextContent());
						insDto.setTransactionType(eElement.getElementsByTagName(CommonConstant.TYPE).item(0).getTextContent());
						insDto.setUnits(Integer.parseInt(eElement.getElementsByTagName(CommonConstant.UNITS).item(0).getTextContent()));
						insDto.setInstructionDate(eElement.getElementsByTagName(CommonConstant.INSTRUCTION_DATE).item(0).getTextContent());
						InstList.add(insDto);
					}
				}
		} catch (ParserConfigurationException pce) {
			LOGGER.log(Level.SEVERE, pce.toString());
		} catch (SAXException saxe) {
			LOGGER.log(Level.SEVERE, saxe.toString());
		} catch (IOException ioe) {
			LOGGER.log(Level.SEVERE, ioe.toString());
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, ex.toString());
		}
		return InstList;
	}
	
	/**
	 * Method to bind data into map based on transaction type either BUY or SELL.
	 * 
	 * @param instDataList List.
	 * @return instructionMap Map.
	 */
	public static Map<String, List<InstructionDTO>> getDataMapForTransaction(List<InstructionDTO> instDataList) {
		
		List<InstructionDTO> incommingInstList = new ArrayList<InstructionDTO>();
		List<InstructionDTO> outgoingInstList = new ArrayList<InstructionDTO>();
		Map<String, List<InstructionDTO>> instructionMap = new HashMap<String, List<InstructionDTO>>();
		for (InstructionDTO insDto : instDataList) {
			insDto.setSettlementDate(getWrokingDate(insDto.getCurrency(), insDto.getSettlementDate()));
			insDto.setRankingTotalAmount(insDto.getPricePerUnit() * insDto.getUnits() * insDto.getAgreedFx());
			if (CommonConstant.TRANSACTION_TYPE_BUY.equalsIgnoreCase(insDto.getTransactionType())) {
				outgoingInstList.add(insDto);
			} else if(CommonConstant.TRANSACTION_TYPE_SELL.equalsIgnoreCase(insDto.getTransactionType())) {
				incommingInstList.add(insDto);
			}
		}
		instructionMap.put(CommonConstant.TRANSACTION_TYPE_BUY, outgoingInstList);
		instructionMap.put(CommonConstant.TRANSACTION_TYPE_SELL, incommingInstList);
		return instructionMap;
	}
	/**
	 * Method to getAppropriate working date.
	 * 
	 * @param currency String
	 * @param settlementDate String
	 * @return formattedDate String
	 */
	public static String getWrokingDate(String currency, String settlementDate) {
		
		Date formattedDate;
		try {
			formattedDate = new SimpleDateFormat(CommonConstant.DATE_FORMAT_DDMMYYYY).parse(settlementDate);
			Calendar c = Calendar.getInstance();
			c.setTime(formattedDate);
			int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
			if (CommonConstant.AED.equalsIgnoreCase(currency) || CommonConstant.SAR.equalsIgnoreCase(currency)) {
				if (dayOfWeek == 6) {
					c.add(Calendar.DATE, 2);
				} else if (dayOfWeek == 7) {
					c.add(Calendar.DATE, 1);
				}
			} else {
				if (dayOfWeek == 7) {
					c.add(Calendar.DATE, 2);
				} else if (dayOfWeek == 1) {
					c.add(Calendar.DATE, 1);
				}
			}
			SimpleDateFormat sdf = new SimpleDateFormat(CommonConstant.DATE_FORMAT_DDMMYYYY);
			return sdf.format(c.getTime());
		} catch (ParseException pex) {
			LOGGER.log(Level.WARNING, pex.toString());
		}
		return "";
	}
	
	/**
	 * Method to calculate total amount.
	 * 
	 * @param instructionList List
	 * @return totalAmountMap Map.
	 */
	public static Map<String, Double> calculateAmount(List<InstructionDTO> instructionList) {
		Set<String> set = new HashSet<String>();
		Map<String, Double> totalAmountMap = new HashMap<String, Double>();
		Double totalAmount;
		for (InstructionDTO instruction : instructionList) {
			totalAmount = instruction.getPricePerUnit() * instruction.getUnits() * instruction.getAgreedFx();
			if (set.add(instruction.getSettlementDate())) {
				totalAmountMap.put(instruction.getSettlementDate(), totalAmount);
			} else {
				totalAmount = totalAmountMap.get(instruction.getSettlementDate()) + totalAmount;
				totalAmountMap.put(instruction.getSettlementDate(), totalAmount);
			}
		}
		return totalAmountMap;
	}
	
	
	public static void printResult(Map<String, Double> instResultMap, String resultType) {
		
		StringBuilder sbResult = new StringBuilder();
		sbResult.append("********"+ resultType +"********");
		sbResult.append("\n");
		sbResult.append("Settlement Date | Total Amount");
		sbResult.append("\n");
		for (String key : instResultMap.keySet()) {
				sbResult.append(key +"      |   "+ instResultMap.get(key));
				sbResult.append("\n");
		}
		sbResult.append("*****************************");
		System.out.println(sbResult);
	}
	
	public static void printRankingResult(List<InstructionDTO> instructionList, String resultType) {
		Collections.sort(instructionList, new Comparator<InstructionDTO>(){
			   public int compare(InstructionDTO inst1, InstructionDTO inst2){
			      return  Double.compare(inst2.getRankingTotalAmount(), inst1.getRankingTotalAmount());
			   }
			});
		StringBuilder sbResult = new StringBuilder();
		sbResult.append("********"+ resultType +"********");
		sbResult.append("\n");
		sbResult.append("Entity | Rank");
		sbResult.append("\n");
		int i = 1;
		for (InstructionDTO instructionDTO : instructionList) {
			sbResult.append(instructionDTO.getEntity() +"    | "+ i);
			sbResult.append("\n");
			i++;
		}
		sbResult.append("*********************");
		System.out.println(sbResult);
	}
}
