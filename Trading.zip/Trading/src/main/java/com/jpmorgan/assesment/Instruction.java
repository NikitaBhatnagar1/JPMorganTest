package com.jpmorgan.assesment;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.jpmorgan.assesment.bl.Utility;
import com.jpmorgan.assesment.common.CommonConstant;
import com.jpmorgan.assesment.dto.InstructionDTO;

/**
 * Entry class to execute the functionality
 * @author
 *
 */
public class Instruction {

	/**
	 * Main method to process Instruction
	 * @param args String array
	 */
	public static void main(String[] args) {
		
		//Get file from resources folder
		File resourcesDirectory = new File("src/main/resources/Instruction.xml");
		
		//Read Data from xml file
		List<InstructionDTO> instructionList = Utility.getInstructionData(resourcesDirectory.getAbsolutePath());
		
		Map<String, List<InstructionDTO>> instructionMap = Utility.getDataMapForTransaction(instructionList);
		
		// Get the Settlement amount for the Incoming instruction
		Map<String, Double> totAmtMapForIncomingInst = Utility.calculateAmount(instructionMap.get(CommonConstant.TRANSACTION_TYPE_SELL));
		Utility.printResult(totAmtMapForIncomingInst, CommonConstant.TOTAL_SELL);
		
		// Get the Settlement amount for the Outgoing instruction
		Map<String, Double> totAmtMapForOutgoingInst = Utility.calculateAmount(instructionMap.get(CommonConstant.TRANSACTION_TYPE_BUY));
		Utility.printResult(totAmtMapForOutgoingInst, CommonConstant.TOTAL_BUY);
		
		//Calculate Ranking For Incoming.
		Utility.printRankingResult(instructionMap.get(CommonConstant.TRANSACTION_TYPE_SELL), CommonConstant.TRANSACTION_TYPE_SELL);
		
		//Calculate Ranking For Outgoing.
		Utility.printRankingResult(instructionMap.get(CommonConstant.TRANSACTION_TYPE_BUY), CommonConstant.TRANSACTION_TYPE_BUY);
	}

}
