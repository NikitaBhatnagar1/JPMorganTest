/**
 * 
 */
package com.jpmorgan.assesment.common;

/**
 * Class to maintain all the static constant.
 * @author
 *
 */
public class CommonConstant {
	
	public static String AED = "AED";
	public static String SAR = "SAR";
	public static String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
	public static String TRANSACTION_TYPE_BUY = "Buy";
	public static String TRANSACTION_TYPE_SELL = "Sell";
	public static String EMPTY = "";
	public static String TOTAL = "TOTAL";
	public static String TOTAL_BUY = "TOTAL BUY";
	public static String TOTAL_SELL = "TOTAL SELL";
	
	//Attribute tag name
	public static String INSTRUCTION = "Instruction";  
	public static String ENTITY = "Entity";
	public static String TYPE = "Type";  
	public static String AGREED_FX = "AgreedFx";
	public static String CURENCY = "Currency";
	public static String INSTRUCTION_DATE = "InstructionDate";
	public static String SETTLEMENT_DATE = "SettlementDate";
	public static String UNITS = "Units";
	public static String PRICE_PER_UNIT = "PricePerUnit";
	
	public static String FILE_PATH = "src\\main\\resources\\instruction.xml";
}
