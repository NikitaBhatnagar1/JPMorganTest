package com.jpmorgan.assesment.bl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.jpmorgan.assesment.common.CommonConstant;
import com.jpmorgan.assesment.dto.InstructionDTO;

public class TestUtility {
	
	@Test
	public void getInstructionDataTest() {
		File resourcesDirectory = new File("src/main/resources/Instruction.xml");
		List<InstructionDTO> InstList = Utility.getInstructionData(resourcesDirectory.getAbsolutePath());
		assertTrue(InstList.size() > 0);
	}
	
	@Test
	public void getDataMapForTransactionTest() {
		List<InstructionDTO> instList = new ArrayList<InstructionDTO>();
		InstructionDTO instruction = getTestData("BUY");
		instList.add(instruction);
		instruction = getTestData("SELL");
		instList.add(instruction);
		
		Map<String, List<InstructionDTO>> instructionMap = Utility.getDataMapForTransaction(instList);
		assertTrue(instructionMap.get(CommonConstant.TRANSACTION_TYPE_BUY).size() > 0);
		assertTrue(instructionMap.get(CommonConstant.TRANSACTION_TYPE_SELL).size() > 0);
	}
	
	@Test
	public void calculateAmountTest() {
		List<InstructionDTO> instList = new ArrayList<InstructionDTO>();
		InstructionDTO instruction = getTestData("BUY");
		instList.add(instruction);
		instruction = getTestData("SELL");
		instList.add(instruction);
		Map<String, Double> totalAmountMap = Utility.calculateAmount(instList);
		Double amount = instruction.getPricePerUnit() * instruction.getUnits() * instruction.getAgreedFx();
		amount = amount * 2;
		assertEquals(totalAmountMap.get(instruction.getSettlementDate()), amount);
	}
	
	
	private InstructionDTO getTestData(String transactionType) {
		InstructionDTO instruction = new InstructionDTO();
		instruction.setAgreedFx(10.10);
		instruction.setCurrency("AED");
		instruction.setEntity("foo");
		instruction.setInstructionDate("24/07/2017");
		instruction.setPricePerUnit(10);
		instruction.setSettlementDate("24/07/2017");
		instruction.setTransactionType(transactionType);
		instruction.setUnits(5);
		return instruction;
	}
}
